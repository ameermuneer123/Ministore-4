package bean;

public class Product {
    public int id;
    public String name;
    public int price;
    public String size;
    public String colour;
    public String storage;
    public String ram;
    public String highlight;
    public String description;
    public String specification;
    public String image_url;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public String getSize() {
		return size;
	}
	public void setSize(String size) {
		this.size = size;
	}
	public String getColor() {
		return colour;
	}
	public void setColor(String color) {
		this.colour = color;
	}
	public String getStorage() {
		return storage;
	}
	public void setStorage(String storage) {
		this.storage = storage;
	}
	public String getRam() {
		return ram;
	}
	public void setRam(String ram) {
		this.ram = ram;
	}
	public String getHighlight() {
		return highlight;
	}
	public void setHighlight(String highlight) {
		this.highlight = highlight;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getSpecification() {
		return specification;
	}
	public void setSpecification(String specification) {
		this.specification = specification;
	}
	public String getImage_url() {
		return image_url;
	}
	public void setImage_url(String image_url) {
		this.image_url = image_url;
	}
	public Product(int id, String name, int price, String size, String color, String storage, String ram,
			String highlight, String description, String specification, String image_url) {
		super();
		this.id = id;
		this.name = name;
		this.price = price;
		this.size = size;
		this.colour = color;
		this.storage = storage;
		this.ram = ram;
		this.highlight = highlight;
		this.description = description;
		this.specification = specification;
		this.image_url = image_url;
	}
	public Product() {
		super();
	}
	public Product(int id, String name, int price) {
		super();
		this.id = id;
		this.name = name;
		this.price = price;
	}
	
	
	
    
}